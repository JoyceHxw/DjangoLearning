from django import forms
from assignment import models
from django.core.exceptions import ValidationError

class ProjectForm(forms.ModelForm):
    def __init__(self,request,*args, **kwargs):
        super().__init__(*args,**kwargs)
        self.request=request
        for _, field in self.fields.items():
            # 指定相应的小部件，attrs表示形式为文本输入 
            field.widget.attrs['class']='form-control'
            field.widget.attrs['placeholder']='请输入%s'%(field.label,)
    # 指定该表单与哪个模型（Model）相关联
    class Meta:
        model=models.ProjectList
        # 如果模型中没有相应的字段，那么表单就没有与之关联的数据存储位置，confirm_password和code不需要存储
        # 由于继承ModelForm，没有显示地定义email,username的表单字段，自动从模型中生成
        fields=['projectname','desc','public']

    # 校验项目名是否存在
    def clean_projectname(self):
        projectname = self.cleaned_data["projectname"]
        # 中间件增加了request属性
        # 这里我们并没有直接使用 self.request.user_obj 的 id 来匹配查找对象，而是使用整个 user_obj 对象作为查询条件。
        # 这样的查询是合法的，因为 Django 的 ORM（Object-Relational Mapping）系统可以根据模型定义的外键关联自动处理查询。
        exists=models.ProjectList.objects.filter(projectname=projectname,creator=self.request.user_obj).exists()

        # 允许修改的名字与原来相同
        # 用于获取与表单关联的模型实例的主键（也称为 ID）。
        if self.instance.pk:
            original_projectname = models.ProjectList.objects.get(pk=self.instance.pk).projectname
            # If the project name is the same as the original name, allow it
            if projectname == original_projectname:
                return projectname
        
        if exists:
            raise ValidationError("项目名已存在")
        return projectname