from django.urls import path,include

from assignment.views import account, login, index, project, manage, search

urlpatterns = [
    # path参数：route：匹配请求的URL，view：匹配URL时调用，name：URL的名称，用于在其他地方引用
    # 注册功能
    path('register/',account.register, name='register'),
    path('register/sms/',account.send_sms, name='send_sms'),
    # 登录功能
    path('login/pwd/',login.login_pwd,name='login_pwd'),
    path('login/image_code/',login.image_code,name='image_code'),
    path('login/sms/',login.login_sms,name='login_sms'),
    path('logout/',login.logout,name='logout'),
    path('index/', project.project_list, name='index'),
    # 项目列表
    path('index/', project.project_list, name='project_list'),
    path('project/star/<str:project_type>/<int:project_id>/', project.project_star, name='project_star'),
    path('project/unstar/<str:project_type>/<int:project_id>/', project.project_unstar, name='project_unstar'),
    path('index/my_project', project.my_project, name='my_project'),
    path('index/my_project_public', project.my_project_public, name='my_project_public'),
    path('index/my_project_private', project.my_project_private, name='my_project_private'),
    path('index/del_my_project', project.del_my_project, name='del_my_project'),
    # 项目管理
    path('manage/<int:project_id>/', include([
        path('wiki/', manage.wiki, name='wiki')

    ])),
    path('search/',search.my_search,name="my_search"),
    path('all_search/',search.all_search,name="all_search"),
]