from django.shortcuts import render
from assignment.models import ProjectList

def my_search(request):
    project_name=request.GET.get('project_name','')
    current_url=request.GET.get('current_url', '')
    projects=ProjectList.objects.filter(projectname__icontains=project_name)
    context={'projects':projects,'search_query':project_name,'current_url':current_url}
    return render(request,'my_search.html',context)
def all_search(request):
    project_name=request.GET.get('project_name','')
    current_url=request.GET.get('current_url', '')
    projects=ProjectList.objects.filter(projectname__icontains=project_name)
    context={'projects':projects,'search_query':project_name,'current_url':current_url}
    return render(request,'all_search.html',context)