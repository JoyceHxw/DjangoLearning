from django.shortcuts import render,redirect, HttpResponse
from assignment.forms.project import ProjectForm
from django.http import JsonResponse
from assignment import models

# 创建我的项目
def my_project(request):
    if request.method=='GET':
        # 展示我的项目
        project_dict={'public':[],'private':[],'all':[]}
        my_list=models.ProjectList.objects.filter(creator=request.user_obj)
        for row in my_list:
            if row.public:
                project_dict['public'].append(row)
            else:
                project_dict['private'].append(row)
            project_dict['all'].append(row)
        form=ProjectForm(request)
        return render(request,'my_project_all.html',{'form':form,'project_dict':project_dict})
    form=ProjectForm(request,data=request.POST)
    if form.is_valid():
        form.instance.creator=request.user_obj
        form.save()
        return JsonResponse({'status':True})
    return JsonResponse({'status':False, 'error':form.errors})

def my_project_public(request):
    if request.method=='GET':
        # 展示我的项目
        project_dict={'public':[],'private':[],'all':[]}
        my_list=models.ProjectList.objects.filter(creator=request.user_obj)
        for row in my_list:
            if row.public:
                project_dict['public'].append(row)
            else:
                project_dict['private'].append(row)
            project_dict['all'].append(row)
        form=ProjectForm(request)
        return render(request,'my_project_public.html',{'form':form,'project_dict':project_dict})
    form=ProjectForm(request,data=request.POST)
    if form.is_valid():
        form.instance.creator=request.user_obj
        form.save()
        return JsonResponse({'status':True})
    return JsonResponse({'status':False, 'error':form.errors})

def my_project_private(request):
    if request.method=='GET':
        # 展示我的项目
        project_dict={'public':[],'private':[],'all':[]}
        my_list=models.ProjectList.objects.filter(creator=request.user_obj)
        for row in my_list:
            if row.public:
                project_dict['public'].append(row)
            else:
                project_dict['private'].append(row)
            project_dict['all'].append(row)
        form=ProjectForm(request)
        return render(request,'my_project_private.html',{'form':form,'project_dict':project_dict})
    form=ProjectForm(request,data=request.POST)
    if form.is_valid():
        form.instance.creator=request.user_obj
        form.save()
        return JsonResponse({'status':True})
    return JsonResponse({'status':False, 'error':form.errors})

# 删除我的项目
def del_my_project(request):
    if request.method == 'POST':
        project_name = request.POST.get('project_name')
        if project_name:
            project = models.ProjectList.objects.get(projectname=project_name)
            if project:
                project.delete()
                return JsonResponse({'status': True})
        return JsonResponse({'status': False})
    return JsonResponse({'status': False})

def project_list(request):
    """ 项目列表显示 """
    if request.method == 'GET':
        project_dict = {'public': [], 'private': [], 'all': [],'star':[]}
        list1 = models.ProjectList.objects.filter()
        for row in list1:
            if row.star:
                project_dict['star'].append(row)
            else:
                if row.public:
                    project_dict['public'].append(row)
                else:
                    project_dict['private'].append(row)
                project_dict['all'].append(row)
        form = ProjectForm(request)
        return render(request, 'index.html', {'form': form, 'project_dict': project_dict})
    form = ProjectForm(request, data=request.POST)
    if form.is_valid():
        form.instance.creator = request.user_obj
        form.save()
        return JsonResponse({'status': True})
    return JsonResponse({'status': False, 'error': form.errors})


def project_star(request,project_type,project_id):
    """星标项目"""
    models.ProjectList.objects.filter(id=project_id).update(star=True)
    return redirect('index')



def project_unstar(request,project_type,project_id):
    """去除星标"""
    models.ProjectList.objects.filter(id=project_id).update(star=False)
    return redirect('index')

