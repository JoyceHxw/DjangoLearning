from django.http import JsonResponse
from django.shortcuts import get_object_or_404, render
from assignment import models
from assignment.forms.project import ProjectForm

def wiki(request, project_id):
    project=get_object_or_404(models.ProjectList, id=project_id)
    if request.method=='GET':
        form=ProjectForm(request,instance=project)
        context={'project':project,'form':form}
        return render(request, 'wiki.html',context)
    form=ProjectForm(request,data=request.POST,instance=project)
    if form.is_valid():
        # form.instance.creator=request.user_obj
        form.save()
        return JsonResponse({'status':True})
    return JsonResponse({'status':False, 'error':form.errors})
