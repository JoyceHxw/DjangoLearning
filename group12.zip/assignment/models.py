from django.db import models

# Create your models here.
# 用户信息
class UserInfo(models.Model):
    username=models.CharField(verbose_name="用户名",max_length=32)
    password=models.CharField(verbose_name="密码",max_length=32)
    email=models.EmailField(verbose_name="邮箱", max_length=254)
    mobile_phone=models.CharField(verbose_name="手机号", max_length=50)


# 我的项目列表
class ProjectList(models.Model):
    projectname=models.CharField(verbose_name='项⽬名', max_length=32)
    desc = models.CharField(verbose_name='项⽬描述', max_length=255, null=True, blank=True)
    public = models.BooleanField(verbose_name='是否公开', default=False)
    # 这是一个外键字段，用于关联 UserInfo 模型中的用户。to='UserInfo' 表示关联到 UserInfo 模型，
    # on_delete=models.CASCADE 表示级联删除，当关联的用户被删除时，与之关联的项目也会被删除。
    # 这里的外键字段 creator 与 UserInfo 模型的关联字段是 id，它是 UserInfo 模型的默认主键字段。
    creator = models.ForeignKey(verbose_name='创建者', to='UserInfo', on_delete=models.CASCADE)
    create_datetime = models.DateTimeField(verbose_name='创建时间', auto_now_add=True)
    star = models.BooleanField(verbose_name='星标', default=False)